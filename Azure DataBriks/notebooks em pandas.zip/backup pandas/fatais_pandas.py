# Databricks notebook source
# MAGIC %md # Analise de dados - Tabela Acidentes Fatais

# COMMAND ----------

# Importando a biblioteca pandas
import pandas as pd
# Importando a biblioteca os - Fornece acesso a funções específicas do sistema para lidar com o sistema de arquivos, processos, planejador
import os
# Importando a biblioteca numpy - Trabalha cálculos numéricos, funções
import numpy as np

# COMMAND ----------

# Leitura do arquivo no Blob Storage e mantendo arquivo em variavel
acidentes_fatais = "/dbfs/mnt/landing/web_scraping/estadual/raw/xlsx/acidentes_fatais.xlsx"

# COMMAND ----------

# Criando Dataframe
df_fatais = pd.read_excel(acidentes_fatais)

# COMMAND ----------

# Contagem de registros - total: 34450 registros e 32 colunas
print('Quantidade de Registros:', df_fatais.shape)

# COMMAND ----------

# Verificando as colunas existentes no arquivo
df_fatais.columns.values

# COMMAND ----------

# DBTITLE 1,Analise para (Retirar Campos)
# LISTA DE TODOS OS CAMPOS: 'Ano BO (RDO)', 'Dia do Acidente', 'Mês do Acidente', 'Ano do Acidente', 'Ano/Mês do Acidente', 'Turno', 'Região Administrativa', 'Administração', 'Conservação', 'Tipo do Local do Acidente','Iluminação da via (SIOPM)',  'Condições Climáticas (SIOPM)', 'Sentido da Via (SIOPM)', 'Limite da velocidade da via (SIOPM)'

# Observações:
# Administração: PREFEITURA, CONCESSIONÁRIA-ARTESP, DER, NAO DISPONIVEL, CONCESSIONÁRIA-ANTT ou DNIT 
# Conservação: 13 Categorias - Prefeitura, Autoban, Novadutra, DRs, EixoSP, Ecovias, Colinas, Autopista
# Tipo do Local do Acidente: Público, Privado ou Não Disponivel

# Contagem de registros por categoria no campo 'Iluminação da via (SIOPM)'
df_fatais['Iluminação da via (SIOPM)'].value_counts()
# 28310 linhas 'nao disponivel' dentre 34450 registros 

# COMMAND ----------

# Contagem de registros por categoria no campo ''Condições Climáticas (SIOPM)'
df_fatais['Condições Climáticas (SIOPM)'].value_counts()
# 28357 linhas 'nao disponivel' dentre 34450 registros

# COMMAND ----------

# Contagem de registros por categoria no campo 'Sentido da Via (SIOPM)'
df_fatais['Sentido da Via (SIOPM)'].value_counts()
# 28309 linhas 'nao disponivel' dentre 34450 registros 

# COMMAND ----------

# Contagem de registros por categoria no campo 'Limite da velocidade da via (SIOPM)'
df_fatais['Limite da velocidade da via (SIOPM)'].value_counts()
# 28301 linhas 'nao disponivel' dentre 33658 registros 

# COMMAND ----------

# DBTITLE 1,Selecionando as colunas
# Criando uma lista 'colunas_fatais' para posteriosmente criar um dataframe com as colunas selecionadas
colunas_fatais = ['ID',
                  'Id Delegacia (RDO)',
                  'Número BO (RDO)',
                  'Data do Acidente',
                  'Dia da semana',  
                  'Hora do Acidente',
                  'Município',
                  'Logradouro',
                  'Numeral / KM',
                  'Jurisdição',
                  'Lat (GEO)',
                  'Long (GEO)',
                  'Superfície da Via (SIOPM)',
                  'Tipo de pista (SIOPM)',
                  'Outro Veículo Envolvido',
                  'Tipo de via',
                  'Quantidade de vítimas',
                  'Tempo entre o Acidente e as Mortes']

# COMMAND ----------

# Criando DataFrame com as colunas selecionadas
dffatais_selec = df_fatais.filter(items = colunas_fatais)

# Imprimindo os campos selecionados
print('Nome dos Campos: ', dffatais_selec.columns.values)

# Imprimindo a quantidade de linhas e colunas
print('Quantidade de linhas, Colunas: ', dffatais_selec.shape)

# COMMAND ----------

# DBTITLE 1,Renomeando as colunas selecionadas 
dffatais_selec.rename(columns={
        'ID': 'id',                                  
        'Id Delegacia (RDO)': 'id_delegacia',
        'Número BO (RDO)': 'numero_bo',
        'Data do Acidente': 'data_acidente',
        'Dia da semana': 'dia_semana',
        'Hora do Acidente': 'hora_acidente',
        'Município': 'municipio',
        'Logradouro': 'logradouro',
        'Numeral / KM': 'km',
        'Jurisdição': 'jurisdicao',
        'Lat (GEO)': 'lat',
        'Long (GEO)': 'long',
        'Superfície da Via (SIOPM)': 'superficie_via',
        'Tipo de pista (SIOPM)': 'tipo_pista',
        'Outro Veículo Envolvido': 'outro_veiculo_envolvido',
        'Tipo de via': 'tipo_via',
        'Quantidade de vítimas': 'quantidade_vitimas',
        'Tempo entre o Acidente e as Mortes': 'tempo_entre_acidente_e_obito',
        },
        inplace=True)

# COMMAND ----------

# Conferindo a quantidade de colunas >18 col
print('Quantidade de linhas, Colunas: ', dffatais_selec.shape)


# COMMAND ----------

# DBTITLE 1,Limpeza dos Dados
# Verificando valores nulos ou faltantes 
dffatais_selec.isnull().sum()

# COMMAND ----------

df = dffatais_selec

# Padroniza a formatação para campos não preenchidos ou não informados
df = df.replace('NAO DISPONIVEL', 'Não Informado'). \
replace(' ', 'Não Informado')

# Percorre em cada coluna e procura por valores nulos e preenche 'Nao informado'
for coluna in df.columns:
  if df[coluna].dtype == 'object':
    df[coluna] = df[coluna].replace(np.nan, 'Não Informado')
  else:
    df[coluna] = df[coluna].replace(np.nan, 0)

# COMMAND ----------

# Conferindo os valores nulos ou faltantes novamente
df.isnull().sum()

# COMMAND ----------

# Para cada valor zerado, altera para 'Nao Informado'
df['lat'] = df['lat'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['lat'] = df['lat'].astype('str').str.replace(',', '.').astype('float')

# Para cada valor zerado, altera para 'Nao Informado'
df['long'] = df['long'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['long'] = df['long'].astype('str').str.replace(',', '.').astype('float')

# COMMAND ----------

# Leitura dos dados no DataFrame
df.head()

# COMMAND ----------

# Tratamento do campo 'KM': Procura valores negativos ou com hífen e altera para 0
df.loc[df['km'] <'0'] = '0'

# COMMAND ----------

# Formatando data pe padronizando para '-'
df['data_acidente'] = df['data_acidente'].replace('/', '-')

# COMMAND ----------

# Padronizando o formato do horário
def ajusta_horario(item):
    if len(item) <=5:
        item = item + ":00"
    return item
  
df.hora_acidente = df.hora_acidente.apply(ajusta_horario)

# COMMAND ----------

# Identificando os valores contidos na coluna 
df['jurisdicao'].unique()

# COMMAND ----------

# Filtro para buscar registros diferentes da jurisdição 'Federal'
df_jurisdicao = df[df['jurisdicao'] != 'FEDERAL']

# COMMAND ----------

# Conferindo valores contidos na coluna 
df_jurisdicao['jurisdicao'].unique()

# COMMAND ----------

# contagem de registros retirando a Jurisdicao Federal >> 32591 linhas, 19 colunas
df_jurisdicao.shape

# COMMAND ----------

df_fatais_final = df_jurisdicao

# COMMAND ----------

df_fatais_final

# COMMAND ----------

df_fatais_final.to_csv("/dbfs/mnt/landing/web_scraping/estadual/lake/acidentes_fatais.csv", index=False, header=True, encoding="iso8859-15")