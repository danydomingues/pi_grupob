# Databricks notebook source
# MAGIC %md # Analise de dados - Tabela Óbitos

# COMMAND ----------

# Importando a biblioteca pandas
import pandas as pd
# Importando a biblioteca os - Fornece acesso a funções específicas do sistema para lidar com o sistema de arquivos, processos, planejador
import os
# Importando a biblioteca numpy - Trabalha cálculos numéricos, funções
import numpy as np

# COMMAND ----------

# Leitura do arquivo no Blob Storage e criação do DataFrame
df_obitos = pd.read_csv("/dbfs/mnt/landing/web_scraping/estadual/raw/csv/obitos.csv", header='infer', sep=";", encoding="iso8859-1")

# COMMAND ----------

# Contagem de registros - total: 36830 registros e 34 colunas
print('Quantidade de Registros:', df_obitos.shape)

# COMMAND ----------

# Verificando as colunas existentes no arquivo
df_obitos.columns.values

# COMMAND ----------

# DBTITLE 1,Analise para (Retirar Campos)
# LISTA DE TODOS OS CAMPOS: 'Ano do BO (RDO)', 'Dia do óbito', Mês do Óbito', 'Ano do Óbito', 'Ano/Mês do Óbito', 'Turno', 'Região Administrativa', 'Administração', 'Conservação','Tipo do local da ocorrência'

# Observações:
# 'Tipo do local da ocorrência': PUBLICO, NAO DISPONIVEL, PRIVADO

# Contagem de registros por categoria no campo 'Tipo do local da ocorrência'
df_obitos['Tipo do local da ocorrência'].value_counts()


# COMMAND ----------

# DBTITLE 1,Selecionando as colunas
colunas_obitos = ['Id da Delegacia (RDO)',
                  'Número do Bo (RDO)',
                  'Data do Óbito',
                  'Data do Acidente',
                  'Tipo de via',
                  'Dia da Semana',
                  'Hora do Acidente',
                  'Município',
                  'Logradouro',
                  'Númeral / KM',
                  'Jurisdição',
                  'LAT_(GEO)', 
                  'LONG_(GEO)',
                  'Tipo do veículo da vítima',
                  'Tipo de vítima', 
                  'Local do óbito',
                  'Tipo de acidente',
                  'Sub Tipo do Acidente', 
                  'Sexo',
                  'Faixa etária',
                  'Idade da vítima', 
                  'Outro Veículo Envolvido',
                  'Tempo entre o Acidente e o Óbito'
  
]

# COMMAND ----------

# Criando DataFrame com as colunas selecionadas
dfobitos_selec = df_obitos.filter(items = colunas_obitos )

# Imprimindo os campos selecionados
print('Nome dos Campos: ', dfobitos_selec.columns.values)

# Imprimindo a quantidade de linhas e colunas
print('Quantidade de linhas, Colunas: ', dfobitos_selec.shape)

# COMMAND ----------

# DBTITLE 1,Renomeando as colunas selecionadas 
dfobitos_selec.rename(columns={
        'Id da Delegacia (RDO)': 'id_delegacia',
        'Número do Bo (RDO)': 'numero_bo',
        'Data do Óbito': 'data_obito',
        'Data do Acidente': 'data_acidente',
        'Tipo de via': 'tipo_via',
        'Dia da Semana': 'dia_semana',
        'Hora do Acidente': 'hora_acidente',
        'Município': 'municipio',
        'Logradouro': 'logradouro',
        'Númeral / KM': 'km',
        'Jurisdição': 'jurisdicao',
        'LAT_(GEO)': 'lat',
        'LONG_(GEO)': 'long',
        'Tipo do veículo da vítima': 'tipo_veiculo_vitima',
        'Tipo de vítima': 'tipo_vitima',
        'Local do óbito': 'local_obito',
        'Tipo de acidente': 'tipo_acidente',
        'Sub Tipo do Acidente': 'sub_tipo_acidente',
        'Sexo': 'sexo',
        'Faixa etária': 'faixa_etaria',
        'Idade da vítima': 'idade_vitima',
        'Outro Veículo Envolvido': 'outro_veiculo_envolvido',
        'Tempo entre o Acidente e o Óbito': 'tempo_entre_acidente_e_obito',
        }, inplace=True)

# COMMAND ----------

# Conferindo a quantidade de colunas >21 col
print('Quantidade de linhas, Colunas: ', dfobitos_selec.shape)

# COMMAND ----------

# DBTITLE 1,Limpeza dos Dados
# Verificando valores nulos ou faltantes 
dfobitos_selec.isnull().sum()

# COMMAND ----------

df = dfobitos_selec

# Padroniza a formatação para campos não preenchidos ou não informados
df = df.replace('NAO DISPONIVEL', 'Não Informado'). \
replace(' ', 'Não Informado')

# Percorre em cada coluna e procura por valores nulos e preenche 'Nao informado'
for coluna in df.columns:
  if df[coluna].dtype == 'object':
    df[coluna] = df[coluna].replace(np.nan, 'Não Informado')
  else:
    df[coluna] = df[coluna].replace(np.nan, 0)

# COMMAND ----------

# Conferindo os valores nulos ou faltantes novamente
df.isnull().sum()

# COMMAND ----------

# Para cada valor zerado, altera para 'Nao Informado'
df['lat'] = df['lat'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['lat'] = df['lat'].astype('str').str.replace(',', '.').astype('float')

# Para cada valor zerado, altera para 'Nao Informado'
df['long'] = df['long'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['long'] = df['long'].astype('str').str.replace(',', '.').astype('float')

# COMMAND ----------

# Leitura dos dados no DataFrame
df.head()

# COMMAND ----------

# Tratamento do campo 'KM': Procura valores negativos ou com hífen e altera para 0
df.loc[df['km'] <'0'] = '0'

# COMMAND ----------

# Formatando data - padronizando de '/' para '-'
df['data_acidente'] = df['data_acidente'].replace('/', '-')
df['data_obito'] = df['data_obito'].replace('/', '-')

# COMMAND ----------

# idade da vitima > tratar idades maiores que 100 anos
df.loc[(df['idade_vitima'] > '100')] = 0

# COMMAND ----------

# Padronizando o formato do horário

def ajusta_horario(item):
    if len(item) <=5:
        item = item + ":00"
    return item

  
df.hora_acidente = df.hora_acidente.apply(ajusta_horario)

# COMMAND ----------

# Identificando os valores contidos na coluna 
df['jurisdicao'].unique()

# COMMAND ----------

# Filtro para buscar registros diferentes da jurisdição 'Federal'
df_jurisdicao = df[df['jurisdicao'] != 'FEDERAL']

# COMMAND ----------

# Conferindo valores contidos na coluna 
df_jurisdicao['jurisdicao'].unique()

# COMMAND ----------

# Contagem de registros retirando a Jurisdicao Federal >> 36827 linhas , 23
df_jurisdicao.shape

# COMMAND ----------

df_obitos_final = df_jurisdicao

# COMMAND ----------

