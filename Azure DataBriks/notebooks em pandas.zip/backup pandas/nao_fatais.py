# Databricks notebook source
# MAGIC %md # Analise de dados - Tabela Acidentes Nao Fatais

# COMMAND ----------

# Importando a biblioteca pandas
import pandas as pd
# Importando a biblioteca os - Fornece acesso a funções específicas do sistema para lidar com o sistema de arquivos, processos, planejador
import os
# Importando a biblioteca numpy - Trabalha cálculos numéricos, funções
import numpy as np

# COMMAND ----------

# DBTITLE 1,Listando o diretório para identificar onde esta o arquivo
# MAGIC %fs ls /mnt/landing/web_scraping/estadual/raw/csv/

# COMMAND ----------

# Leitura do arquivo no Blob Storage e mantendo arquivo em variavel
df_naofatais = pd.read_csv("/dbfs/mnt/landing/web_scraping/estadual/raw/csv/acidentes_nao_fatais.csv", header='infer', sep=";", encoding="iso8859-1")

# COMMAND ----------

# Contagem de registros - total: 451424 registros e 49 colunas
print('Quantidade de Registros:', df_naofatais.shape)

# COMMAND ----------

# Verificando as colunas existentes no arquivo
df_naofatais.columns.values

# COMMAND ----------

# DBTITLE 1,Analise para (Retirar Campos)
# LISTA DE TODOS OS CAMPOS: 'Dia do Acidente', 'Mês do Acidente', 'Ano do Acidente','Ano/Mês do Acidente', 'Batalhão de Trânsito', 'Companhia de Trânsito','Região Administrativa', 'Administração', 'Conservaçao', 'Mão de direção', 'Obras na pista', 'Traçado','Serviço de Atendimento - Bombeiro','Serviço de Atendimento - PMRV', 'Serviço de Atendimento - PRF', 'Turno + Dia de Semana'

# Observações:
# Batalhão de Trânsito: 1º BPTran e 2º BPTran
# Companhia de Trânsito: 2ª CIA P TRAN, 3ª CIA P TRAN e 1ª CIA P TRAN 
# Administração: PREFEITURA,CONCESSIONÁRIA-ARTESP, DER, NAO DISPONIVEL,CONCESSIONÁRIA-ANTT e DNIT
# Conservação: 21 Categorias - Prefeitura, Autoban, Novadutra, DRs, EixoSP, Ecovias, Colinas, Autopista
# Mão de direção: NAO DISPONIVEL,DUPLA,ÚNICA, NÃO, SIM

# Contagem de registros por categoria no campo 'Obras na pista'
df_naofatais['Obras na pista'].value_counts()
# possui 441602 linhas 'nao disponivel' dentre 451424 registros 

# COMMAND ----------

# Contagem de registros por categoria no campo 'Traçado'
df_naofatais['Tipo de Via'].value_counts()
# possui 198174 linhas 'nao disponivel' dentre 451424 registros 

# COMMAND ----------

# DBTITLE 1,Selecionando as colunas
# Criando uma lista 'colunas_fatais' para posteriosmente criar um dataframe com as colunas selecionadas
colunas_selecionadas = ['ID',
                     'Data do Acidente',
                     'Dia da Semana',
                     'Hora do Acidente',
                     'Município',
                     'Logradouro',
                     'Numero/KM',
                     'Jurisdição',
                     'LAT_(GEO)',
                     'LONG_(GEO)',
                     'Condições Climáticas',
                     'Iluminação',
                     'Relevo', 
                     'Superfície da via',
                     'Tipo de pavimento',
                     'Tipo de pista',             
                     'Veículos Envolvidos - Bicicleta',
                     'Veículos Envolvidos - Caminhão',
                     'Veículos Envolvidos - Automóvel',
                     'Veículos Envolvidos - Motocicleta',
                     'Veículos Envolvidos - Ônibus',
                     'Veículos Envolvidos - Pedestre',
                     'Pessoas Envolvidas - Grave',
                     'Pessoas Envolvidas - Ileso',
                     'Pessoas Envolvidas - Leve',
                     'Tipo de Via',
                     'Tipo de Acidente - Atropelamento',
                     'Tipo de Acidente - Choque',
                     'Tipo de Acidente - Colisão',
                     'Tipo de Acidente - Outros tipos de Acidente'
                    ]
# Verificar possibilidade de juntar em uma coluna os Veiculos Envolvidos e Tipo de Acidente

# COMMAND ----------

# Criando DataFrame com as colunas selecionadas
dfnaofatais_selec = df_naofatais.filter(items = colunas_selecionadas)

# Imprimindo os campos selecionados
print('Nome dos Campos: ', dfnaofatais_selec.columns.values)

# Imprimindo a quantidade de linhas e colunas
print('Quantidade de linhas, Colunas: ', dfnaofatais_selec.shape)

# COMMAND ----------

# DBTITLE 1,Renomeando as colunas selecionadas 
 dfnaofatais_selec.rename(columns={
        'ID': 'id',
        'Data do Acidente': 'data_acidente',
        'Ano/Mês do Acidente': 'ano_mes_acidente',
        'Dia da Semana': 'dia_semana',
        'Hora do Acidente': 'hora_acidente',
        'Turno': 'turno',
        'Município': 'municipio',
        'Logradouro': 'logradouro',
        'Numero/KM': 'km',
        'Jurisdição': 'jurisdicao',
        'LAT_(GEO)': 'lat',
        'LONG_(GEO)': 'long',
        'Condições Climáticas': 'clima',
        'Iluminação': 'iluminacao',
        'Relevo': 'relevo',
        'Superfície da via': 'superficie_via',
        'Tipo de pavimento': 'tipo_pavimento',
        'Tipo de pista': 'tipo_pista',
        'Veículos Envolvidos - Bicicleta': 'vei_env_bicicleta',
        'Veículos Envolvidos - Caminhão': 'vei_env_caminhao',
        'Veículos Envolvidos - Automóvel': 'vei_env_automovel',
        'Veículos Envolvidos - Motocicleta': 'vei_env_motocicleta',
        'Veículos Envolvidos - Ônibus': 'vei_env_onibus',
        'Veículos Envolvidos - Pedestre': 'vei_env_pedestre',
        'Pessoas Envolvidas - Grave': 'pes_env_grave',
        'Pessoas Envolvidas - Ileso': 'pes_env_ileso',
        'Pessoas Envolvidas - Leve': 'pes_env_leve',
        'Tipo de Via': 'tipo_via',
        'Tipo de Acidente - Atropelamento': 'tipo_acidente_atropelamento',
        'Tipo de Acidente - Choque': 'tipo_acidente_choque',
        'Tipo de Acidente - Colisão': 'tipo_acidente_colisao',
        'Tipo de Acidente - Outros tipos de Acidente': 'tipo_acidente_outros',
        }, inplace=True)

# COMMAND ----------

# Conferindo a quantidade de colunas >30 col
print('Quantidade de linhas, Colunas: ', dfnaofatais_selec.shape)


# COMMAND ----------

# DBTITLE 1,Limpeza dos Dados
# Verificando valores nulos ou faltantes 
dfnaofatais_selec.isnull().sum()

# COMMAND ----------

df = dfnaofatais_selec

# Padroniza a formatação para campos não preenchidos ou não informados
df = df.replace('NAO DISPONIVEL', 'Não Informado'). \
replace(' ', 'Não Informado')

# Percorre em cada coluna e procura por valores nulos e preenche 'Nao informado'
for coluna in df.columns:
  if df[coluna].dtype == 'object':
    df[coluna] = df[coluna].replace(np.nan, 'Não Informado')
  else:
    df[coluna] = df[coluna].replace(np.nan, 0)

# COMMAND ----------

# Conferindo os valores nulos ou faltantes novamente
df.isnull().sum()

# COMMAND ----------

# Para cada valor zerado, altera para 'Nao Informado'
df['lat'] = df['lat'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['lat'] = df['lat'].astype('str').str.replace(',', '.').astype('float')

# Para cada valor zerado, altera para 'Nao Informado'
df['long'] = df['long'].replace('Não Informado', '0,0')

# Alteração do tipo (str p/ float) e da ',' para o ponto '.' 
df['long'] = df['long'].astype('str').str.replace(',', '.').astype('float')

# COMMAND ----------

# Leitura do Data Frame
df.head()

# COMMAND ----------

# Conferindo dados negativos no campo 'KM'
df.loc[df['km'] <'0']

# COMMAND ----------

# Tratamento do campo 'KM': Procura valores negativos ou com hífen e altera para 0
df.loc[df['km'] <'0'] = '0'

# COMMAND ----------

# Formatando data pe padronizando para '-'
df['data_acidente'] = df['data_acidente'].replace('/', '-')

# COMMAND ----------

# Padronizando o formato do horário
def ajusta_horario(item):
    if len(item) <=5:
        item = item + ":00"
    return item
  
df.hora_acidente = df.hora_acidente.apply(ajusta_horario)

# COMMAND ----------

# Identificando os valores contidos na coluna 
df['jurisdicao'].unique()

# COMMAND ----------

# Filtro para buscar registros diferentes da jurisdição 'Federal'
df_jurisdicao = df[df['jurisdicao'] != 'FEDERAL']

# COMMAND ----------

# Conferindo valores contidos na coluna 
df_jurisdicao['jurisdicao'].unique()

# COMMAND ----------

# Contagem de registros retirando a Jurisdicao Federal >> 442358 linhas , 31
df_jurisdicao.shape

# COMMAND ----------

df_fatais_final = df_jurisdicao

# COMMAND ----------

df_fatais_final.to_csv("/dbfs/mnt/landing/web_scraping/estadual/lake/acidentes_nao_fatais.csv", index=False, header=True, encoding="iso8859-15")