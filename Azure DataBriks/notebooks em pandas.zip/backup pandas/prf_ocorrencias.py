# Databricks notebook source
# MAGIC %md # Analise de dados - Registros de Acidentes da PRF - Por Ocorrências

# COMMAND ----------

# Importando a biblioteca pandas
import pandas as pd

# COMMAND ----------

# Listando o diretório para identificar os arquivos
%fs ls /mnt/landing/web_scraping/prf/raw/ocorrencias

# COMMAND ----------

# Leitura do arquivo no Blob Storage e criação dos DataFrames (2019, 2020 e 2021 separadamente)
df_ocorrencias_2019 = pd.read_csv("/dbfs/mnt/landing/web_scraping/prf/raw/ocorrencias/datatran2019.csv", header='infer', sep=";", encoding="iso8859-1")
df_ocorrencias_2020 = pd.read_csv("/dbfs/mnt/landing/web_scraping/prf/raw/ocorrencias/datatran2020.csv", header='infer', sep=";", encoding="iso8859-1")
df_ocorrencias_2021 = pd.read_csv("/dbfs/mnt/landing/web_scraping/prf/raw/ocorrencias/datatran2021.csv", header='infer', sep=";", encoding="iso8859-1")

# COMMAND ----------

# Contagem de registros no ano 
print('Registros de 2019 :' , df_ocorrencias_2019.shape)  # 67446 registros
print('Registros de 2020 :' , df_ocorrencias_2020.shape)  # 63548 registros
print('Registros de 2021 :' , df_ocorrencias_2021.shape)  # 30901 registros

# COMMAND ----------

# Lendo o DataFrame
df_ocorrencias_2019.head()

# COMMAND ----------

# Cancatenando os três Dataframes com os campos iguais em apenas um ;
df_ocorrencias = pd.concat([df_ocorrencias_2019, df_ocorrencias_2020, df_ocorrencias_2021])

# COMMAND ----------

# Total de registros após a concatenacao dos anos 2019, 2020 e 2021 em um Dataframe - 161895 registros
print('Registros de todos Concatenados:', df_ocorrencias.shape)

# COMMAND ----------

# Identificando as colunas a serem filtradas
df_ocorrencias.columns.values

# COMMAND ----------

# Renomeando os campos 'condicao_metereologica' que esta incorreto,data_inversa para data_acidente e fase_dia para turno
df_ocorrencias.rename(columns= {'condicao_metereologica': 'condicao_meteorologica',
                                'data_inversa': 'data_acidente',
                                'fase_dia': 'turno'
                               }, inplace=True)

# COMMAND ----------

# Selecionando as colunas a serem utilizadas
colunas_selecionadas = ['id',
                        'data_acidente',
                        'dia_semana',
                        'horario',
                        'uf',
                        'br',
                        'km',
                        'municipio',
                        'causa_acidente',
                        'tipo_acidente',
                        'classificacao_acidente',
                        'turno',
                        'condicao_meteorologica',
                        'tracado_via',
                        'tipo_pista',
                        'pessoas',
                        'mortos',
                        'feridos_leves',
                        'feridos_graves',
                        'ilesos',
                        'ignorados',
                        'feridos',
                        'veiculos',
                        'latitude',
                        'longitude'
                       ]

# COMMAND ----------

# atribuindo ao DataFrame df_oc_selec, somente os campos selecionados 
df_oc_selec = df_ocorrencias.filter(items = colunas_selecionadas)

# listando os valores das colunas
df_oc_selec.columns.values

# COMMAND ----------

# Identificando os valores contidos na coluna 
df_oc_selec ['uf'].unique()

# COMMAND ----------

# Filtrando registros apenas de SP
df_SP = df_oc_selec[df_oc_selec['uf'] == 'SP']

# COMMAND ----------

# Contagem de registros após o filtro por UF 
df_SP.shape  # 10429 registros


# COMMAND ----------

